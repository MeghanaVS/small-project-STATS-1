tf.idf <- function(df, col_name){
  tf <- TfIdfVectorizer$new(min_df = 0.7, max_features = 5000, remove_stopwords = TRUE)
  print(Sys.time())
  tf$fit(df[,col_name])
  tf_features = tf$transform(df[,col_name])
  print(Sys.time())
  return(tf_features)
}








