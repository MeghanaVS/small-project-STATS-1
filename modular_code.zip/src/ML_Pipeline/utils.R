read.data <- function(path,separator){
  df = read.csv(file = path, sep = separator, header = TRUE)
  return(df)
}
