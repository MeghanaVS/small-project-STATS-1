count.vect <- function(df,col_name){
  cv <- CountVectorizer$new(min_df = 0.7, max_features = 5000, remove_stopwords = TRUE)
  print(Sys.time())
  cv$fit(df[, col_name])
  cv_features = cv$transform(df[, col_name])
  print(Sys.time())
  return(cv_features)
}
