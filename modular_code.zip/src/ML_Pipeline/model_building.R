dtree <- function(df, y_col, model_file_path){
  dt <- rpart(df[,y_col] ~ . , data = df)
  saveRDS(dt,model_file_path)
  print(paste('Model saved in ', model_file_path))
  return(dt)
}


rf_model <- function(df, y_col, model_file_path,  mtry = 10){
  rf <- randomForest(df[,y_col] ~ ., data = df, mtry = mtry, importance = TRUE) 
  saveRDS(rf,model_file_path)
  print(paste('Model saved in ', model_file_path))
  return(rf)
}

svm_model <- function(df, y_col,  model_file_path, kernel='linear'){
  svm_obj = svm(formula = df[,y_col] ~ ., data = df, kernel = kernel)
  saveRDS(svm_obj,model_file_path)
  print(paste('Model saved in ', model_file_path))
  return(svm_obj)
}

gbm_model <- function(df, y_col, model_file_path, n_trees=50,distribution = 'gaussian'){
  gbm_obj <- gbm(formula = df[,y_col] ~ .,data = df, distribution = distribution,n.trees = n_trees)
  saveRDS(gbm_obj,model_file_path)
  print(paste('Model saved in ', model_file_path))
  return(gbm_obj)
}



