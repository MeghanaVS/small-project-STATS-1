lbl.encoder <- function(df, col_name, new_col_name){
  lbl_obj <- LabelEncoder$new()
  lbl_obj$fit(df[ , col_name])
  df[new_col_name] <- lbl_obj$transform(df[ , col_name])
  return(df)
}