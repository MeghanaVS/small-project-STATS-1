replace.nan.entries <- function(col_name,  replace_with, df){
  df[col_name][df[col_name]== ""] <- replace_with 
  return(df)
}

fill.nan.entries <- function(col_name, replace_with, df){
  df[col_name] = na.fill(df[col_name], replace_with)
  return(df)
}

lemmatization <- function(df, col_name, new_col_name){
  df[new_col_name] = lemmatize_strings(df[ ,col_name])
  return(df)
}