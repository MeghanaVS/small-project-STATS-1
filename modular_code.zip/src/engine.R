options(warn=-1)
library(dplyr)
library(tidyr)
library(superml)
library(zoo)
library(textstem)
library(stringr)
library(randomForest) 
library(e1071)
library(neuralnet)
library(caret)
library(Metrics)
library(data.table)
library(ggplot2)
library(plyr)
library(gbm)
library(rpart)
library(quanteda)
library(tm)
library(mlbench)
source("ML_Pipeline/utils.R")
source("ML_Pipeline/data_manipulation.R")
source("ML_Pipeline/label_encoding.R")
source("ML_Pipeline/count_vectorizer.R")
source("ML_Pipeline/tfidf_vectorizer.R")
source("Ml_Pipeline/model_building.R")

train_df <- read.data('../input/train.tsv', separator = '\t')
test_df <- read.data('../input/test.tsv', separator = '\t')
train_df = head(train_df,500)
# handling nan
train_df = replace.nan.entries(col_name = 'brand_name',  replace_with = "Unknown brand", df=train_df)
train_df = fill.nan.entries(col_name = 'brand_name',  replace_with = "Unknown brand", df=train_df)
train_df = replace.nan.entries(col_name = 'category_name',  replace_with = "Other/Other/Other", df=train_df)
train_df = fill.nan.entries(col_name = 'category_name',  replace_with = "Other/Other/Other", df=train_df)
train_df = replace.nan.entries(col_name = 'item_description',  replace_with = "No description", df=train_df)
train_df = fill.nan.entries(col_name = 'item_description',  replace_with = "No description", df=train_df)
# feature engg
category_name = train_df$category_name
train_df = separate(data = train_df, col = category_name, into = c("main_category", "subcat_1", "subcat_2"), sep="/")
train_df$category_name = category_name
# label encoding
train_df <- lbl.encoder(df=train_df, col_name = 'main_category', new_col_name = 'n_main_category')
train_df <- lbl.encoder(df=train_df, col_name = 'brand_name', new_col_name = 'n_brand_name')
train_df <- lbl.encoder(df=train_df, col_name = 'subcat_1', new_col_name = 'n_subcat_1')
train_df <- lbl.encoder(df=train_df, col_name = 'subcat_2', new_col_name = 'n_subcat_2')
# Removing the rows which is not having proper description
train_df <- subset(train_df, item_description != "No description yet")
#replace unwanted symbols
train_df$description = str_replace_all(train_df$item_description, "[[:punct:]]", " ")
#Lemmatization
train_df = lemmatization(df = train_df, col_name = 'description', new_col_name = 'clean_description')
# Making all the text lower case
train_df$lower_clean_description = tolower(train_df$clean_description)
# count vectorizarion
cv_features <- count.vect(df=train_df, col_name = 'lower_clean_description')
cv_df = train_df[ , c('item_condition_id', 'n_main_category', 'n_subcat_1', 'n_subcat_2', 'n_brand_name', 'price', 'shipping')]
colnames(cv_df) <- c('item_condition_id', 'n_main_category', 'n_subcat_1', 'n_subcat_2', 'n_brand_name', 'n_price', 'n_shipping')
cv_df = cbind(cv_df,data.frame(cv_features))
cv_df = data.frame(lapply(cv_df, as.integer))
# tfidf 
tf_features <- tf.idf(df=train_df, col_name = 'lower_clean_description')
tf_df = train_df[ , c('item_condition_id', 'n_main_category', 'n_subcat_1', 'n_subcat_2', 'n_brand_name', 'price', 'shipping')]
colnames(tf_df) <- c('item_condition_id', 'n_main_category', 'n_subcat_1', 'n_subcat_2', 'n_brand_name', 'n_price', 'n_shipping')
tf_df = cbind(tf_df,data.frame(tf_features))
tf_df = data.frame(lapply(tf_df, as.integer))

# dtree 
cv_dt = dtree(df=cv_df, y_col = 'n_price', model_file_path = "../output/dtree_cv_sample.rds")
tf_dt = dtree(df=tf_df, y_col = 'n_price', model_file_path = "../output/dtree_tf_sample.rds")
# random forest
cv_rf = rf_model(df=cv_df, y_col = 'n_price',  model_file_path = "../output/rf_cv_sample.rds", mtry = 100)
tf_rf = rf_model(df=tf_df, y_col = 'n_price',  model_file_path = "../output/rf_tf_sample.rds", mtry = 100)

# SVM
cv_svm <- svm_model(df=cv_df, y_col='n_price', model_file_path = "../output/svm_cv_linear_sample.rds", kernel='linear')
cv_svm <- svm_model(df=cv_df, y_col='n_price', model_file_path = "../output/svm_cv_radial_sample.rds", kernel='radial')
cv_svm <- svm_model(df=cv_df, y_col='n_price', model_file_path = "../output/svm_cv_poly_sample.rds", kernel='poly')

tf_svm <- svm_model(df=tf_df, y_col='n_price', model_file_path = "../output/svm_tf_linear_sample.rds", kernel='linear')
tf_svm <- svm_model(df=tf_df, y_col='n_price', model_file_path = "../output/svm_tf_radial_sample.rds", kernel='radial')
tf_svm <- svm_model(df=tf_df, y_col='n_price',model_file_path = "../output/svm_tf_poly_sample.rds",kernel='poly')

# GBM
cv_gbm <- gbm_model(df = cv_df, y_col = 'n_price',  model_file_path = "../output/gbm_cv_sample.rds", n_trees = 50)
tf_gbm <- gbm_model(df = tf_df, y_col = 'n_price',  model_file_path = "../output/gbm_tf_sample.rds",n_trees = 50)

# Neural network
cv_nn = neuralnet(n_price ~ ., data = cv_df, hidden = 3 , linear.output = T, stepmax=1e+06 )
tf_nn = neuralnet(n_price ~ ., data = tf_df, hidden = 3 , linear.output = T, stepmax=1e+06 )

# Model Comparison
tf_results <- data.frame(Test = c("MAE","MAPE","RMSE","MSE"),
           DecisionTree = c(mae(tf_df$n_price, predict(tf_dt,tf_df)),mape(tf_df$n_price, predict(tf_dt,tf_df)),rmse(tf_df$n_price, predict(tf_dt,tf_df)),mse(tf_df$n_price, predict(tf_dt,tf_df))),
           RandomForest = c(mae(tf_df$n_price, predict(tf_rf,tf_df)),mape(tf_df$n_price, predict(tf_rf,tf_df)),rmse(tf_df$n_price, predict(tf_rf,tf_df)),mse(tf_df$n_price, predict(tf_rf,tf_df))),
           SVM = c(mae(tf_df$n_price, predict(tf_svm,tf_df)),mape(tf_df$n_price, predict(tf_svm,tf_df)),rmse(tf_df$n_price, predict(tf_svm,tf_df)),mse(tf_df$n_price, predict(tf_svm,tf_df))),
           nn = c(mae(tf_df$n_price, compute(tf_nn,head(tf_df,1))$net.result),mape(tf_df$n_price, compute(tf_nn,head(tf_df,1))$net.result),rmse(tf_df$n_price, compute(tf_nn,head(tf_df,1))$net.result),mse(tf_df$n_price, compute(tf_nn,head(tf_df,1))$net.result)))
cv_results <- data.frame(Test = c("MAE","MAPE","RMSE","MSE"),
                         DecisionTree = c(mae(cv_df$n_price, predict(cv_dt,cv_df)),mape(cv_df$n_price, predict(cv_dt,cv_df)),rmse(cv_df$n_price, predict(cv_dt,cv_df)),mse(cv_df$n_price, predict(cv_dt,cv_df))),
                         RandomForest = c(mae(cv_df$n_price, predict(cv_rf,cv_df)),mape(cv_df$n_price, predict(cv_rf,cv_df)),rmse(cv_df$n_price, predict(cv_rf,cv_df)),mse(cv_df$n_price, predict(cv_rf,cv_df))),
                         SVM = c(mae(cv_df$n_price, predict(cv_svm,cv_df)),mape(cv_df$n_price, predict(cv_svm,cv_df)),rmse(cv_df$n_price, predict(cv_svm,cv_df)),mse(cv_df$n_price, predict(cv_svm,cv_df))),
                         nn = c(mae(cv_df$n_price, compute(cv_nn,(cv_df))$net.result),mape(cv_df$n_price, compute(cv_nn,(cv_df))$net.result),rmse(cv_df$n_price, compute(cv_nn,(cv_df))$net.result),mse(cv_df$n_price, compute(cv_nn,(cv_df))$net.result)))




